from setuptools import setup, find_packages

setup(
    description="CLI for pulling OpenFDA test_data.",
    entry_points={
        "console_scripts": ["file-signature-detection = file_signature_detection.cli:cli"]
    },
    name="file_signature_detection",
    packages=find_packages(),
    version=0.1,
    zip_safe=True,
    # install_requires=["click", "fire", "requests"],
    package_data={
        'file_signature_detection': ['data/*.txt']
    }
)
